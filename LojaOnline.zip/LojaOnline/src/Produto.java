public class Produto {
    private String calca;
    private double preco;

    public Produto(String calca, double preco) {
        this.calca = calca;
        this.preco = preco;
    }

    public String getCalca() {
        return calca;
    }

    public double getPreco() {
        return preco;
    }

}
