public interface DescontoStrategy{
    double calcularDesconto(double preco);
}
